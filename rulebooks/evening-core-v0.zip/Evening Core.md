## Introduction

![[Introduction]]
## The Rules

![[The Rules]]

## Dice Checks

![[Dice Checks]]

## Effect

![[Effect]]

## Structure of Play

![[Structure of Play]]

## Formats

![[Formats]]

## Character Creation

![[Character Creation]]

## Progression

![[Progression]]

## Origins

![[Origins]]

## Classes

![[Classes]]

## Focus

![[Focus]]

## Discipline

![[Discipline]]

## Defense

![[Defense]]

## Resting

![[Resting]]

## Reserves

![[Reserves]]

## Threads

![[Threads]]

## Initiative

![[Initiative]]

## Equipment

![[Equipment]]

## Resources

![[Resources]]

## Movement

![[Movement]]

## Size

![[Size]]

## Environment

![[Environment]]

## Challenges

![[Challenges]]

## Threats

![[Threats]]

## Dangers

![[Dangers]]

## Combat

![[Combat]]

## Damage & Health

![[Damage & Health]]

## Injury

![[Injury]]

## Exhaustion

![[Exhaustion]]

## Death

![[Death]]

## Conditions

![[Conditions]]
