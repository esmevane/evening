The overall shape and condition of the character’s physical Body. How fit or healthy the character is. Pick Body whenever a character needs to make any kind of physical check.
