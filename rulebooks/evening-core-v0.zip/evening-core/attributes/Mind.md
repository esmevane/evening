The overall condition and clarity of the character’s Mind. How intelligent or intuitive a given character is. Pick Mind whenever a character needs to make any kind of mental check.
