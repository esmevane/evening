---
Kind: Martial
Summary: Close combat with weaponry.
Status: draft
tag:
  - srd
---
Quick thinking in close range with a weapon of some kind is incredibly hard, but characters with an aptitude in melee are familiar with it. Use melee whenever you need to understand what's going on in a fracas, or navigate it either to deadly or safe ends. Melee aptitude may be applied to any [[Combat|attack]] check made in melee range with a melee weapon.

**Using without aptitude.** If you try to engage in melee combat without the melee aptitude, you do so with -2 modifying your check.