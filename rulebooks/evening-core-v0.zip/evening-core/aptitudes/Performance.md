---
Kind: Skill
Status: draft
Summary: Training in ceremonies and the expression of art.
tag:
  - srd
---
Ceremony and art serve tremendous purpose, and characters with a Performance aptitude are dedicated to that purpose somehow. Whether through intent to preserve the past, document the present, entertain, or otherwise sway, performers tend to be passionate and driven by a junction of this purpose and their own taste. Many things can be made into a performance: dancing, acting, oration, rituals, writing, and so on. Whenever any of these things are done, the Performance aptitude can be applied.