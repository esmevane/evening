---
Kind: Knowledge
Status: draft
Summary: Knowledge of the past, cultures, and nations.
tag:
  - srd
---
History is an expression of knowledge about any given thing a character may be aware of. Use it to recognize dead languages, understand the local politics of a nearby village, remember a story from long ago, or to safely navigate a ruin via recollection of the cultures which originally dwelled there.
