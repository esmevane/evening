---
Kind: Martial
Summary: Handling of shields and armor.
Status: draft
tag:
  - srd
---
Panoply reflects your ability to employ, care for, and operate with varying kinds of armor and personal defenses. Creatively using armor and weapons, knowing how they work and how to identify them, and functioning without the armor slowing you down: panoply helps with all of it. If you are apt in panoply, you have dozens of ways to be a bulwark on the battlefield, clad in foreboding armor yet unhindered by it.

**Using without aptitude.** Attempting to wear armor or shields to defend yourself without the panoply aptitude reduces your speed by 2.