---
Kind: Martial
Summary: Expertise with martial tactics and weaponry.
Status: draft
tag:
  - srd
---
Endurance is an aptitude with general toughness, reflecting a character whose core devotion involves strengthening their body's overall resolve and durability. Characters who are apt with endurance are able to use it for [[core/Defense|defense]] checks to endure harm and to shrug off effects that might test their constitution: poisons, diseases, and so on.