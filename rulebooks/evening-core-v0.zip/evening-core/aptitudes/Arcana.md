---
Kind: Knowledge
Status: draft
Summary: Occult lore and spiritual knowledge.
tag: srd
---
Arcana represents your experience with the eldritch and supernatural. It helps you recognize and understand and recall the otherworldly. The strange, alien, angelic, demonic, and so on. Pick arcana as your aptitude whenever you seek to discover, understand, recall, or use mystic knowledge of the occult and supernatural.
