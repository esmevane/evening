---
Kind: Knowledge
Status: draft
Summary: Studied observation and deductive reasoning.
tag:
  - srd
---
When consciously poring over your surroundings and making connections between each observation you make, or collecting details and reviewing them time and time again, or tracing the evidence of one circumstance until it connects to another, use your Investigation aptitude. Nearly anything can be a clue and any attempt to discover a clue, interpret a clue, or assemble clues into a greater mosaic of understanding can prompt some kind of Investigation check.
