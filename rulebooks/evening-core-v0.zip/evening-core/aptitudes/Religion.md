---
Kind: Knowledge
Status: draft
Summary: Familiarity with the faiths and their followings.
tag:
  - srd
---
You've invested heavily either in the practice of ceremonial religion, or the study of it. You needn't be narrowed in on a single religion: you might be very well-versed in a diverse array of religions. Use religion whenever you need to understand or interpret rituals and prayers, navigate religious hierarchies, identify holy artifacts or decipher the practices of clandestine cults.
