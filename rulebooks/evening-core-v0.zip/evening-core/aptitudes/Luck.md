---
Kind: Wealth
Status: draft
Summary: You don't want for much in life, you trust the cosmos and it provides.
tag:
  - srd
---
It's kind of hard to put you in a position where the world doesn't come to your side. While your luck doesn't apply broadly, making you into a fortunate fool, you do have a strangely compelling fortune. You may apply your luck to find things you need in a pinch, or to realize something which should be terribly obvious, or to remember something you really should've written down.