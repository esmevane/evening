---
Kind: Skill
Status: draft
Summary: The arts and tricks of stealth, deception, and sleight of hand.
tag:
  - srd
---
Subterfuge is the grand art of legerdemain and skullduggery. You know where to hide, both in the immediate sense and the larger cultural sense. Sleight of hand, stealth, navigating the underworld, planting or digging up rumors, pick-pocketing, and so on: subterfuge helps you in each.
