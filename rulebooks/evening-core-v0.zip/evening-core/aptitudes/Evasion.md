---
Kind: Martial
Summary: Reflexes and avoidance.
Status: draft
tag:
  - srd
---
As an aptitude, evasion depicts your ability to move fast in the moment, getting out of the way of harm almost by reflex. You may use evasion on [[core/Defense|defense]] checks that involve speed, reflexes or dextrous motion, and in order to avoid harm from melee and ranged attacks by getting out of the way.