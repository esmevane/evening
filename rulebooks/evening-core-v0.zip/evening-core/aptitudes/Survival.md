---
Kind: Skill
Status: draft
Summary: Learning to thrive in the wilderness, or amongst the wild.
tag:
  - srd
---
Whenever you need to travel the wilds or interact with domestic or wild animals, use your survival aptitude. Navigation, hunting, awareness of the local beasts and the dangers or risks of the land and its plant life, taming and befriending or husbanding animals: all of these use your survivel aptitude.