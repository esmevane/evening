---
Kind: Skill
Status: draft
Summary: Persuasion, diplomacy, intimidation, and other forms of negotiation.
tag:
  - srd
---
Your aptitude with coercion reflects your ability to intimidate, deceive, or persuade. It encompasses the work you've put in to learn how to get, or promote, exactly what you want. Either subtly or overtly, with good or ill intent, pick coercion whenever you need to convince someone else of something.