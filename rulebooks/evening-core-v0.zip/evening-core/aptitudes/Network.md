---
Kind: Wealth
Status: draft
Summary: You have a broad network of friends and allies who support you.
tag:
  - srd
---
You make connections wherever you go, bonding with people or even beasts, often in unexpected ways. Over time, you've established a network of helpers of some kind, and you may call on them when you need. Apply your network whenever you want to call in favors of some kind, or when in need of a friend.