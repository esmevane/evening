---
Kind: Skill
Status: draft
Summary: Investment in the body and physical excellence.
tag:
  - srd
---
Whenever you use your body to do something strenuous and it poses a risk of some kind: jumping, climbing, running, lifting, etc., use your athletics aptitude. Athletics reflects your investment in your own body, improving your overall strength, acrobatics, and dexterity.