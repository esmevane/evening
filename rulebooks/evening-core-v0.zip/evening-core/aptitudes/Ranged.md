---
Kind: Martial
Summary: The discipline of bows and ranged weaponry.
Status: draft
tag:
  - srd
---
You are a disciple of the ranged arts: bows, crossbows, thrown knives, take your pick. You've spent long enough with these devices that you've learned how they all work and you've built a technique for yourself with them as well. You can identify them, you know when others are adept in their use, and you're very deadly with them in pinch. Use your ranged aptitude whenever knowledge of ranged weaponry or tactics applies, or whenever making a ranged attack in combat.

**Using without aptitude.** If you try to engage in ranged combat without the ranged aptitude, you do so with -2 modifying your check.