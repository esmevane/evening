---
Kind: Knowledge
Status: draft
Summary: Knowledge of biology and the health of living beings.
tag:
  - srd
---
A character practiced in the ways of Medicine understands physiology and biology of all sorts of sentient beings and creatures. They understand the signs and nature of contagion, they perceive the reasoning for cleanliness and they know the ins and outs of the organic body. Medicine can help you understand compounds you ingest, and how they interact with different creatures. It can help you diagnose illness or general disease. With Medicine, you may attempt surgery safely, stabilize the wounded, and effectively triage survivors.
