---
Kind: Wealth
Status: draft
Summary: You make what you need and you build what you have.
tag:
  - srd
---
Your ingenuity is very respectable. Either you're good at creation or crafting, or you're incredibly skilled at figuring out how to make do with the things around you. Whenever you need to improvise tooling, create or craft something from your own design, or produce something useful from your surroundings, use invention.