---
Kind: Wealth
Status: draft
Summary: You've got a job of some sort and it supports you with a regular stipend.
tag:
  - srd
---
You're gainfully employed in some way, shape, or form which doesn't get in the way of your day to day interests much. Either you're a mercenary or a tradesperson, or a healer or performer.  What this means is that you've got disposable income, and you can use it when in need. Use your salary whenever you need to establish ownership of something, convince others to do work on your behalf, or to obtain assets of any kind.