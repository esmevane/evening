---
Kind: Skill
Status: draft
Summary: Honing the senses and leveraging intuition and insight.
tag:
  - srd
---
Use awareness whenever you need to leverage your senses, take in your surroundings, spot something, or identify the hidden. Awareness works both in physical and social contexts: use awareness whenever you need insight into someone's motives, understand body language, or to see through deception.