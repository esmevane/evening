---
Kind: Wealth
Status: draft
Summary: You broker in favors, and you've found ways to always have a few in
  your back pocket in case you need them.
tag:
  - srd
---
Characters with a trade aptitude are canny at brokering deals of all kinds: from favors to practical arrangements, they know the ins and outs of purveying product. Whenever you need to understand or navigate trade bureaucracies, negotiate trades of any kind, or manage the exchange of assets or trade logistics, use trade.