---
Kind: Wealth
Status: draft
Summary: You or your family have a decent sized estate which can produce a lot
  of what you need.
tag:
  - srd
---
You come from a position of privilege, and have a massive estate at your disposal. Through some means or another, it benefits you wherever you go. You can go more places, you have access to more means, and so on. Whenever you need to employ your prestige, or acquire some necessary assets, use your estate.