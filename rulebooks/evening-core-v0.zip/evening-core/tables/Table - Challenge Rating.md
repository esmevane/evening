---
tags:
  - challenge
  - ratings
  - tables
  - core
  - srd
updated: 2023-12-28
---

| Base | Target Number |
| ---- | ---- |
| 1 | 3 |
| 2 | 6 |
| 3 | 9 |
| 4 | 12 |
| 5 | 15 |
| 6 | 18 |
| 7 | 21 |
| 8 | 24 |
| 9 | 27 |
| 10 | 30 