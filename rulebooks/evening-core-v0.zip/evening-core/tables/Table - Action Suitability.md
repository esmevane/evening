---
tags:
  - tables
  - srd
  - core
  - actions
updated: 2023-12-28
---
| Action Suitability | Target Number Modifier |
| ---- | ---- |
| Poor | +6 |
| Risky | +3 |
| Fine | - |
| Good | -3 |
| Perfect | -6 |