---
tags:
  - injury
  - tables
  - core
  - srd
updated: 2023-12-29
---
| Injury level | Effect |
| :--: | :--- |
| 0 | None |
| 1 | -3 to aptitude checks |
| 2 | -3 to attack and defense rolls |
| 3 | -6 to aptitude checks |
| 4 | -6 to attack and defense rolls |
| 5 | -9 to aptitude checks |
| 6 | -9 to attack and defense rolls |
| 7 | Death |