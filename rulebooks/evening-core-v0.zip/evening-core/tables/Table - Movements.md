---
tags:
  - movement
  - tables
  - core
  - srd
updated: 2023-12-28
---
| Range | Distance |
| ---- | :--: |
| Touch | 1 |
| Adjacent | 2 |
| Close | 5 |
| Near | 10 |
| Medium | 20 |
| Long | 30 |
