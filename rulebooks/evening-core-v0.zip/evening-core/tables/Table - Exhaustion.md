---
tags:
  - tables
  - exhaustion
  - core
  - srd
updated: 2023-12-29
---
| Exhaustion level | Effect |
| :--: | :--- |
| 0 | None |
| 1 | Disadvantage on aptitude checks |
| 2 | Speed halved |
| 3 | Disadvantage on attacks and defenses |
| 4 | Health maximum is halved |
| 5 | Speed reduced to 0 |
| 6 | Death |