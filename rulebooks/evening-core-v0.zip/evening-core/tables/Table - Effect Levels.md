---
tags:
  - tables
  - effects
  - core
  - srd
updated: 2023-12-28
---
| Effect level | Summary |
| ---- | ---- |
| No effect | You're too limited to make it happen. Figure out a better way to do it and then try again. |
| Limited | Something prevents you from giving it your all. |
| Standard | You accomplish what you wanted to, no better and no worse. |
| Strong | You do better than expected. |
| Great | The stars have aligned, and you've done an incredible job. |