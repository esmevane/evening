---
tags:
  - origins
  - progression
  - tables
  - core
  - srd
updated: 2023-12-28
---
| Character Level | Feature |
| :--: | :--- |
| 1st | Origin kit, origin level (1) |
| 5th | Origin level (2) |
| 9th | Origin level (3) |
| 13th | Origin level (4) |
| 17th | Origin level (5) |