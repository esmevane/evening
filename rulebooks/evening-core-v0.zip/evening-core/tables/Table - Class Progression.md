---
tags:
  - classes
  - tables
  - progression
  - core
  - srd
updated: 2023-12-28
---
| Character Level | Feature |
| :--: | :--- |
| 1st | Class kit, class level (1) |
| 5th | Class level (2) |
| 9th | Class level (3) |
| 13th | Class level (4) |
| 17th | Class level (5) |
| 20th | Class level (6) |