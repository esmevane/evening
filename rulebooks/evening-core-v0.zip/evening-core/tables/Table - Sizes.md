---
tags:
  - size
  - tables
  - srd
  - core
updated: 2023-12-28
---
| Size | Space | Load Capacity |
| :--: | :--: | :--: |
| Tiny | 1 | +0 |
| Small | 1 | +0 |
| Medium | 1 | +1 |
| Large | 2 | +2 |
| Huge | 3 | +3 |
| Gargantuan | 4 | +4 |

