---
tags:
  - disciplines
  - tables
  - progression
  - core
  - srd
updated: 2023-12-28
---
| Character Level | Feature |
| :--: | :--- |
| 2nd | Discipline kit, discipline level (1) |
| 6th | Discipline level (2) |
| 10th | Discipline level (3) |
| 14th | Discipline level (4) |
| 18th | Discipline level (5) |