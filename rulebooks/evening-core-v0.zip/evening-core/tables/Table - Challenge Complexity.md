---
tags:
  - challenge
  - complexity
  - tables
  - core
  - srd
updated: 2023-12-28
---
| Complexity | Successes Required | Failure Threshold |
| ---- | ---- | ---- |
| 1 | 3 | 2 |
| 2 | 4 | 2 |
| 3 | 5 | 3 |
| 4 | 6 | 3 |
| 5 | 7 | 4 |
| 6 | 8 | 4 |
| 7 | 9 | 5 |
| 8 | 10 | 5 |
| 9 | 11 | 6 |
| 10 | 12 | 6 |