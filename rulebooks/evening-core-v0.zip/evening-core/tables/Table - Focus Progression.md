---
tags:
  - focuses
  - progression
  - tables
  - core
  - srd
updated: 2023-12-28
---
| Character Level | Feature |
| :--: | :--- |
| 3rd | Focus kit, focus level (1) |
| 7th | Focus level (2) |
| 11th | Focus level (3) |
| 15th | Focus level (4) |
| 19th | Focus level (5) |