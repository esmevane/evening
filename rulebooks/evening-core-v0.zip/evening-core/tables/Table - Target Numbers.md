---
tags:
  - tables
  - target-numbers
  - core
  - srd
updated: 2023-12-28
---
| Difficulty | Target Number | Summary |
| ---- | ---- | ---- |
| Standard | 10 | An even chance of success or failure. |
| Skilled | 15 | An artisan or expert can do it. |
| Difficult | 20 | Rare to see anyone do it. |
| Extremely Hard | 25 | Heroes have done it, supposedly. |
| Impossible | 30 | An unheard of task, legendary. |